Introduction
	- This is a game developed by a student of "University of Applied Sciences Europe".
	- The game is made by Artem Gulyaev, Geumseong Han and Lenny Steve Jox.
	- The aim of the game is to reach the top without touching the lava
	- Run “Bounce.exe” to play the game

How to Pay
	- Jump from platform to platform
	- Get to the final level (lvl 4)